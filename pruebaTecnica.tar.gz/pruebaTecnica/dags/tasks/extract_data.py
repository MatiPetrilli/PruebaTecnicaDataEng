import requests
import json
# import psycopg2
from airflow.hooks.postgres_hook import PostgresHook

def get_fire_incidents(date):
    
    url = f"https://data.sfgov.org/resource/wr8u-xric.json?$where=incident_date >= '{date}'"

    response = requests.get(url).text
    response = json.loads(response)
    
    return response
    
def getConnFromAirflow():
    hook = PostgresHook(postgres_conn_id='airflow')
    conn = hook.get_conn()
    return conn

# def create_conn():
#     conn = psycopg2.connect(database="airflow",
#                             host="localhost",
#                             user="airflow",
#                             password="airflow",
#                             port="54320")
    
#     return conn

def getMaxDateInserted(conn):
    query = """select max(incident_date) from "DataWarehouse".fire_incidents_raw"""
    cursor = conn.cursor()
    cursor.execute(query)
    raw = cursor.fetchone()
    print(raw)
    if raw is None: 
        return '2023-01-01'
    else: 
        return raw[0]

def getKeyFromItem(item,key):
    if key == 'point':
        return str(item[key]['coordinates'])
    else:
        return "'"+ str(item[key]).replace('N None','') +"'" if item.get(key) else "Null"

def fromJsonToPostgres(data,conn):

    cursor = conn.cursor()
    for item in data:
        print("imprimo item")
        print(item)
        
        incident_number = getKeyFromItem(item,'incident_number')
        exposure_number = getKeyFromItem(item,'exposure_number')
        id = getKeyFromItem(item,'id')
        address = getKeyFromItem(item,'address')
        incident_date = getKeyFromItem(item,'incident_date')
        call_number = getKeyFromItem(item,'call_number')
        alarm_dttm = getKeyFromItem(item,'alarm_dttm')
        arrival_dttm = getKeyFromItem(item,'arrival_dttm')
        close_dttm = getKeyFromItem(item,'close_dttm')
        city = getKeyFromItem(item,'city')
        zipcode = getKeyFromItem(item,'zipcode')
        battalion = getKeyFromItem(item,'battalion')
        station_area = getKeyFromItem(item,'station_area')
        box = getKeyFromItem(item,'box')
        suppression_units = getKeyFromItem(item,'suppression_units')
        suppression_personnel = getKeyFromItem(item,'suppression_personnel')
        ems_units = getKeyFromItem(item,'ems_units')
        ems_personnel = getKeyFromItem(item,'ems_personnel')
        other_units = getKeyFromItem(item,'other_units')
        other_personnel = getKeyFromItem(item,'other_personnel')
        first_unit_on_scene = getKeyFromItem(item,'first_unit_on_scene')
        estimated_property_loss = getKeyFromItem(item,'estimated_property_loss')
        estimated_contents_loss = getKeyFromItem(item,'estimated_contents_loss')
        fire_fatalities = getKeyFromItem(item,'fire_fatalities')
        fire_injuries = getKeyFromItem(item,'fire_injuries')
        civilian_fatalities = getKeyFromItem(item,'civilian_fatalities')
        civilian_injuries = getKeyFromItem(item,'civilian_injuries')
        number_of_alarms = getKeyFromItem(item,'number_of_alarms')
        primary_situation = getKeyFromItem(item,'primary_situation')
        mutual_aid = getKeyFromItem(item,'mutual_aid')
        action_taken_primary = getKeyFromItem(item,'action_taken_primary')
        action_taken_secondary = getKeyFromItem(item,'action_taken_secondary')
        action_taken_other = getKeyFromItem(item,'action_taken_other')
        detector_alerted_occupants = getKeyFromItem(item,'detector_alerted_occupants')
        property_use = getKeyFromItem(item,'property_use')
        area_of_fire_origin = getKeyFromItem(item,'area_of_fire_origin')
        ignition_cause = getKeyFromItem(item,'ignition_cause')
        ignition_factor_primary = getKeyFromItem(item,'ignition_factor_primary')
        ignition_factor_secondary = getKeyFromItem(item,'ignition_factor_secondary')
        heat_source = getKeyFromItem(item,'heat_source')
        item_first_ignited = getKeyFromItem(item,'item_first_ignited')
        human_factors_associated = getKeyFromItem(item,'human_factors_associated_with_ignition')
        structure_type = getKeyFromItem(item,'structure_type')
        structure_status = getKeyFromItem(item,'structure_status')
        floor_of_fire_origin = getKeyFromItem(item,'floor_of_fire_origin')
        fire_spread = getKeyFromItem(item,'fire_spread')
        no_flame_spead = getKeyFromItem(item,'no_flame_spead')
        floors_with_minimum_damage = getKeyFromItem(item,'number_of_floors_with_minimum_damage')
        floors_with_significant_damage = getKeyFromItem(item,'number_of_floors_with_significant_damage')
        floors_with_heavy_damage = getKeyFromItem(item,'number_of_floors_with_heavy_damage')
        floors_with_extreme_damage = getKeyFromItem(item,'number_of_floors_with_extreme_damage')
        detectors_present = getKeyFromItem(item,'detectors_present')
        detector_type = getKeyFromItem(item,'detector_type')
        detector_operation = getKeyFromItem(item,'detector_operation')
        detector_effectiveness = getKeyFromItem(item,'detector_effectiveness')
        detector_failure_reason = getKeyFromItem(item,'detector_failure_reason')
        automatic_extinguishing_system_present = getKeyFromItem(item,'automatic_extinguishing_system_present')
        automatic_extinguishing_sytem_type = getKeyFromItem(item,'automatic_extinguishing_sytem_type')
        automatic_extinguishing_sytem_perfomance = getKeyFromItem(item,'automatic_extinguishing_sytem_perfomance')
        automatic_extinguishing_sytem_failure_reason = getKeyFromItem(item,'automatic_extinguishing_sytem_failure_reason')
        number_of_sprinkler_heads_operating = getKeyFromItem(item,'number_of_sprinkler_heads_operating')
        supervisor_district = getKeyFromItem(item,'supervisor_district')
        neighborhood_district = getKeyFromItem(item,'neighborhood_district')
        point = getKeyFromItem(item,'point')
        
        query = f"""INSERT INTO "DataWarehouse".fire_incidents_raw (incident_number, exposure_number, address, incident_date, call_number, alarm_dttm, arrival_dttm, close_dttm, city, zipcode, battalion, station_area, box, suppression_units, suppression_personnel, ems_units, ems_personnel, other_units, other_personnel, first_unit_on_scene, estimated_property_loss, estimated_contents_loss, fire_fatalities, fire_injuries, civilian_fatalities, civilian_injuries, number_of_alarms, primary_situation, mutual_aid, action_taken_primary, action_taken_secondary, action_taken_other, detector_alerted_occupants, property_use, area_of_fire_origin, ignition_cause, ignition_factor_primary, ignition_factor_secondary, heat_source, item_first_ignited, human_factors_associated, structure_type, structure_status, floor_of_fire_origin, fire_spread, \
no_flame_spead, floors_with_minimum_damage, floors_with_significant_damage, floors_with_heavy_damage, floors_with_extreme_damage, detectors_present, detector_type, detector_operation, detector_effectiveness, detector_failure_reason, automatic_extinguishing_system_present, automatic_extinguishing_sytem_type, automatic_extinguishing_sytem_perfomance, automatic_extinguishing_sytem_failure_reason, number_of_sprinkler_heads_operating, supervisor_district, neighborhood_district, point)
VALUES({incident_number},{exposure_number},{address},{incident_date},{call_number},\
{alarm_dttm},{arrival_dttm},{close_dttm},{city},{zipcode},{battalion},{station_area},\
{box},{suppression_units},{suppression_personnel},{ems_units},{ems_personnel},{other_units},\
{other_personnel},{first_unit_on_scene},{estimated_property_loss},{estimated_contents_loss},\
{fire_fatalities},{fire_injuries},{civilian_fatalities},{civilian_injuries},{number_of_alarms},\
{primary_situation},{mutual_aid},{action_taken_primary},{action_taken_secondary},{action_taken_other},\
{detector_alerted_occupants},{property_use},{area_of_fire_origin},{ignition_cause},{ignition_factor_primary},\
{ignition_factor_secondary},{heat_source},{item_first_ignited},{human_factors_associated},{structure_type},\
{structure_status},{floor_of_fire_origin},{fire_spread},{no_flame_spead},{floors_with_minimum_damage},\
{floors_with_significant_damage},{floors_with_heavy_damage},{floors_with_extreme_damage},{detectors_present},\
{detector_type},{detector_operation},{detector_effectiveness},{detector_failure_reason},{automatic_extinguishing_system_present},\
{automatic_extinguishing_sytem_type},{automatic_extinguishing_sytem_perfomance},{automatic_extinguishing_sytem_failure_reason},\
{number_of_sprinkler_heads_operating},{supervisor_district},{neighborhood_district},'{point}'); """

        print(query)
        cursor.execute(query)
        conn.commit()
        
        
def main():
    #Levanto conexion
    conn = getConnFromAirflow()
        
    #Traigo la ultima fecha cargada
    max_date = getMaxDateInserted(conn)
    print(max_date)
    
    #Traigo los incidentes desde la ultima carga.
    data = get_fire_incidents(max_date)
    
    #Inserto en la BD
    fromJsonToPostgres(data,conn)
    
    conn.close()
    
    
main()


