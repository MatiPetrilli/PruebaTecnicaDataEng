from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.providers.postgres.operators.postgres import PostgresOperator
from datetime import datetime
from airflow.utils.dates import timedelta
import tasks.extract_data as extract_data

with DAG (
    dag_id = "pipeline",
    # default_args=default_args,
    start_date= datetime(2023,5,11),
    schedule_interval='0 9 * * *'
) as dag:
    task_1 = PythonOperator(
        task_id="1_Extract_Api",
        python_callable= extract_data.main,
        retry_delay=timedelta(seconds=5)
    )
    task_2 = PostgresOperator(
        task_id="2_Load_Dw",
        postgres_conn_id = "airflow",
        sql = """
                call  "DataWarehouse".create_dw()
        """
    )
    
    task_1 >> task_2